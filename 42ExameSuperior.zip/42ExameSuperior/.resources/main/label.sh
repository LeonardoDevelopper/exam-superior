source colors.sh
printf "${BG_BLUE}${WHITE}%s${RESET}\n" "░░██╗██╗██████╗░"
printf "${BG_BLUE}${WHITE}%s${RESET}\n" "░██╔╝██║╚════██╗"
printf "${BG_BLUE}${WHITE}%s${RESET}\n" "██╔╝░██║░░███╔═╝"
printf "${BG_BLUE}${WHITE}%s${RESET}\n" "███████║██╔══╝░░"
printf "${BG_BLUE}${WHITE}%s${RESET}\n" "╚════██║███████╗LUANDA"
printf "${BG_BLUE}${WHITE}%s${RESET}" "░░░░░╚═╝╚══════╝"
printf "${BOLD}${WHITE}%s${RESET}\n" " EXAME SUPERIOR"
