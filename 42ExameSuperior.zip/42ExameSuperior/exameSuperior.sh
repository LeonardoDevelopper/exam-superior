#!/bin/bash

cd .resources/main/
bash menu.sh
