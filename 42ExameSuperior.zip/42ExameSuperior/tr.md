## Kurulum Talimatlari

ilk olarak git clone komutuyla repo'yu istediginiz dizine clonelayin.
> git clone https://github.com/emreakdik/42ExamPractice

Daha sonra 42ExamPractice dizinine gidin ve terminalden asagidaki komutu calistirin.
> bash exampractice.sh

Tebrikler shell'e ulastiniz.


## Kullanici Talimatlari


Shell'in kullanimi gayet basit. Secim ekranlarinda hangi sinavi ve hangi leveli pratik yapmak istiyorsaniz onu secmeniz gerekiyor.

Karsiniza sorular ciktiktan sonra yapabileceginiz birden fazla hareket var. Bunlar;

- Subject'in istedigi kodu yazdiktan sonra "test" yazarak kodunuzu test edebilirsiniz.
- Siradaki subject'e gecmek icin "next" yazabilirsiniz.
- Menuye donmek icin "menu" yazabilirsiniz.
- Shell'den cikis yapmak icin "exit" yazabilirsiniz.

> Komutlari ana menudeki Commands secenegini secerekte gorebilirsiniz.

## Kodlarimi nereye yazacagim?

Shell'in kodunuzu dogru sekilde bulabilmesi ve test etmesi icin kodunuzu yazdiginiz konumu sinavdaymis gibi belirlemeniz gerekmektir.

Menuye eristiginiz zaman program 42ExamPractice klasorunun icinde "rendu" klasoru olusturacaktir. Ornegin first_word sorusunu cozmeye calistiginizi dusunelim. 

Yapmaniz gereken, rendu klasorunun icinde first_word klasoru olusturup kodunuzu first_word.c dosyasinin icine yazmalisiniz.
